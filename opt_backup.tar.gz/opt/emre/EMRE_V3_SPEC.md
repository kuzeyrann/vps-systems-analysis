# EMRE v3 – Paket-1
- TP1 mikro refleks (korunur)
- TP2-3-4 HTF likidite hedefleri
- Stop nefesli (vol/atr/news çarpanı)
- HTF cache (15m/1h/4h/1d seyrek)
- Binance fetch: retry/backoff/timeout
ENV:
- EMRE_NEWS_RISK=LOW|MED|HIGH
