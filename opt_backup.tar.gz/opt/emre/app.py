#!/usr/bin/env python3
# -*- coding: utf-8 -*-

from core.core import run

print("=== EMRE başlatılıyor (Modüler Core) ===")
run()
