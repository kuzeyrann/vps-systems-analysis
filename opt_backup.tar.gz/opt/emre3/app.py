#!/usr/bin/env python3
# -*- coding: utf-8 -*-

from core.core import run

print("=== EMRE3 TEST (BB Sendromu Fix) başlatılıyor ===")
print("=== Daralan piyasa filtresi AKTİF ===")
print("=== Bollinger band farkındalığı AKTİF ===")
run()
